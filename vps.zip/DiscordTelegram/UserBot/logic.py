import discord
from telethon.sync import TelegramClient
from telethon.tl.types import PeerChannel


def launch(config):
    client = discord.Client()
    tg_client = TelegramClient(config.session_name, config.api_id, config.api_hash)

    tg_client.start(bot_token=config.telegram_token)

    @client.event
    async def on_ready():
        await client.change_presence(status=discord.Status.invisible)

    @client.event
    async def on_message(message):

        channel_entity = config.mapping.get(message.channel.id)
        if not channel_entity:
            return

        valid_message = channel_entity.validate(message.content)
        if isinstance(valid_message, bool):
            return

        channel_id = channel_entity.channel_id
        channel = await tg_client.get_entity(PeerChannel(channel_id))

        if message.attachments:
            for index, file in enumerate(message.attachments):
                new_file = await file.to_file()
                if len(valid_message) != 0 and index == 0:
                    await tg_client.send_file(channel, new_file.fp, caption=valid_message)
                else:
                    await tg_client.send_file(channel, new_file.fp)

        elif message.embeds:
            tg_client.parse_mode = "html"
            for index, embed in enumerate(message.embeds):

                title = embed.title
                if not title:
                    title = ""
                description = embed.description
                if not description:
                    description = ""
                footer = embed.footer.text 
                if not footer:
                    footer = ""
                e_fields = "\n\n"
                if embed.fields:
                    for field in embed.fields:
                        e_fields += f"<b>{field.name}</b>\n{field.value}\n\n"
                message = f"<b>{title}</b>\n\n{description}{e_fields}<i>{footer}</i>"
                valid_embed_message = channel_entity.validate(message)
                image = embed.image

                if not valid_embed_message:
                    continue

                if index == 0 and len(valid_message) != 0:
                    await tg_client.send_message(channel, valid_message)

                if image:
                    if image.url:
                        if len(valid_embed_message) != 0:
                            await tg_client.send_file(channel, image.url, caption=valid_embed_message)
                        else:
                            await tg_client.send_file(channel, image.url)
                    elif image.proxy_url:
                        if len(valid_embed_message) != 0:
                            await tg_client.send_file(channel, image.proxy_url, caption=valid_embed_message)
                        else:
                            await tg_client.send_file(channel, image.proxy_url)

                elif len(valid_embed_message) != 0:
                    await tg_client.send_message(channel, valid_embed_message)
            tg_client.parse_mode = None

        elif len(valid_message) != 0:
            await tg_client.send_message(channel, valid_message)

    client.run(config.discord_token)
