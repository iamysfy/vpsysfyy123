import logic
from load import load

configuration_name = "sample"

if __name__ == "__main__":
    print("Loading the configuration...")
    config = load(configuration_name)
    print("Connecting channels...")
    logic.launch(config)
