from telethon import TelegramClient, events
from telethon.tl.types import PeerChannel, UpdateShortChatMessage ,UpdateNewMessage, UpdateNewChannelMessage


def launch(config):
    client = TelegramClient(config.session_name, config.api_id, config.api_hash)

    @client.on(events.NewMessage())
    async def _(event) -> None:

        if isinstance(event.original_update, UpdateShortChatMessage):
            channel_id = event.chat_id
        elif isinstance(event.original_update, UpdateNewChannelMessage):
            channel_id = event.peer_id.channel_id
        elif isinstance(event.original_update, UpdateNewMessage):
            channel_id = event.peer_id.chat_id
        else:
            channel_id = 0

        channel_entity = config.mapping.get(abs(channel_id))
        if not channel_entity:
            return

        valid_message = channel_entity.validate(event.message.message)
        if isinstance(valid_message, bool):
            return

        channel_id = channel_entity.channel_id
        channel = await client.get_entity(PeerChannel(channel_id))

        repl_msg = None
        if event.reply_to:
            for their_id, our_id in channel_entity.message_reply_link:
                if their_id == event.reply_to.reply_to_msg_id:
                    repl_msg = our_id
                    break

        if event.message.photo:

            sent_msg = await client.send_file(channel,
                                              event.message.photo,
                                              caption=valid_message,
                                              reply_to=repl_msg)
            channel_entity.message_reply_link.append((event.message.id, sent_msg.id))

        else:
            sent_msg = await client.send_message(channel, valid_message, reply_to=repl_msg)
            channel_entity.message_reply_link.append((event.message.id, sent_msg.id))

        if len(channel_entity.message_reply_link) > channel_entity.message_reply_link_history_limit:
            channel_entity.message_reply_link.popleft()

    print("Channels connected succesfully !")
    client.start()
    client.run_until_disconnected()
