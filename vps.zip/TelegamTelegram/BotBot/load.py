import json
from entities import conf, channel_entity


def load(config_name):

    with open("config.json") as file:
        configs = json.load(file)

    config = configs[config_name]

    mapping = {}

    for channel_name in config["channels"]:
        channel = config["channels"][channel_name]
        mapping[channel["source_id"]] = channel_entity(
            name=channel_name,
            channel_id=channel["channel_id"],
            show_name=channel["show_name"],
            filt=channel["filt"],
            repl=channel["repl"],
            black=channel["black"],
            filter_links=channel["filter_links"],
            globals_=channel["globals"],
            globs=(config["globals"]["filter"], config["globals"]["replace"], config["globals"]["blacklist"]),
            translate=channel["translate"],
            language=["language"],
            formatting_mode=channel["formatting_mode"],
            empty_content_limiter=channel["empty_limit"],
            message_history_limit=channel["history_limit"],
            message_reply_link_history_limit=channel["reply_limit"])

    config = conf(config_name,
                  config["config details"]["api_id"],
                  config["config details"]["api_hash"],
                  config["config details"]["session_name"],
                  config["config details"]["telegram_token"],
                  mapping)

    return config
