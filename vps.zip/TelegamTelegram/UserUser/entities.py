from collections import deque
from googletrans import Translator


class conf:

    def __init__(self, config_name, api_id, api_hash, session_name, mapping):
        self.config_name = config_name
        self.api_id = api_id
        self.api_hash = api_hash
        self.session_name = session_name
        self.mapping = mapping


class channel_entity:

    def __init__(self,
                 name="unknown",
                 channel_id=0,
                 show_name=False,
                 filt=[], repl=[], black=[],
                 filter_links=[],
                 globals_=True,
                 globs=([], [], []),
                 translate=False,
                 language="en",
                 formatting_mode=None,
                 strip_random=True,
                 empty_content_limiter=3,
                 message_history_limit=20,
                 message_reply_link_history_limit=100,
                 ):
        self.name = name
        self.channel_id = channel_id
        self.filt = filt
        self.repl = repl
        self.black = black
        self.messages = deque()
        self.message_history_limit = message_history_limit
        self.globals_ = globals_
        self.translate = translate
        self.language = language
        self.empty_content_limiter = empty_content_limiter
        self.empty_content_curr = 0
        self.global_filter, self.global_replace, self.global_blacklist = globs
        self.show_name = show_name
        self.formatting_mode = formatting_mode
        self.filter_links = filter_links
        self.strip_random = strip_random
        self.message_reply_link = deque()
        self.message_reply_link_history_limit = message_reply_link_history_limit

    def trans(self, text) -> str:
        translator = Translator()
        translated = translator.translate(text, dest=self.language)
        return translated.text

    def link_filter(self, text):
        for link in self.filter_links:
            text = text.replace("\n", "\n#newline#").replace(" ", " #space#")
            splitted = text.split()
            for index in range(len(splitted)):
                if link in splitted[index] and "http" in splitted[index]:
                    splitted[index] = splitted[index].replace(splitted[index], " ") if "#space#" in splitted[index] else splitted[index].replace(splitted[index], "\n")
            text = "".join(splitted)
            text = text.replace("#newline#", "\n").replace("#space#", " ")
        return text.strip().replace("\n ", "\n")

    def blacklisted(self, text, black) -> bool:

        for forbidden in black:
            if forbidden in text:
                return True

        return False

    def replace_func(self, text, repl) -> str:

        for hide, show in repl:
            text = text.replace(hide, show)

        return text

    def filter_func(self, text, filt) -> str:

        for hide in filt:
            text = text.replace(hide, "")

        return text

    def rose_chat_format(self, text) -> str:
        user, _, text = text.partition(":")
        text = text.lstrip()
        text = f"👤 {user}:\n{text[0].upper()}{text[1:]}"
        return text

    def strip_random_func(self, text) -> str:
        text = text.strip()
        ending = ""
        for index in range(len(text)-1, -1, -1):
            char = text[index]
            if not char.isalpha() and not char.isdecimal():
                ending += char
            else:
                break
        text = text[::-1]
        text = text.replace(ending, "", 1)
        return text[::-1]

    def format(self, text):
        if self.formatting_mode == 0:
            return text

    def validate(self, text):

        # Custom blacklist
        if len(self.black) != 0:
            if self.blacklisted(text, self.black):
                return False

        # Global blacklist -> replace -> filter
        if self.globals_:
            if self.blacklisted(text, self.global_blacklist):
                return False
            text = self.replace_func(text, self.global_replace)
            text = self.filter_func(text, self.global_filter)

        # Checks message length, prevention of empty message limit override
        if len(text) == 0 and self.empty_content_curr + 1 > self.empty_content_limiter:
            return False
        elif len(text) == 0:
            self.empty_content_curr += 1
            return text
        else:
            self.empty_content_curr = 0

        # Spam prevention
        if len(self.messages) != 0:
            if text in self.messages:
                return False
            else:
                self.messages.append(text)
                if len(self.messages) == self.message_history_limit:
                    self.messages.popleft()
        else:
            self.messages.append(text)

        # Filter custom links
        if len(self.filter_links) != 0:
            text = self.link_filter(text)

        # Custom replace
        if len(self.repl) != 0:
            text = self.replace_func(text, self.repl)

        # Custom filter
        if len(self.filt) != 0:
            text = self.filter_func(text, self.filt)

        # Format based on current format mode
        text = self.format(text)

        # Add channel name to text
        if self.show_name:
            text = f"{self.name}\n\n{text}"

        # Translate
        if self.translate:
            text = self.trans(text)

        # Removes random characters from end of the text
        if self.strip_random:
            text = self.strip_random_func(text)

        return text
