
- Essential installations:
1. pip install telethon
2. pip install googletrans

- Understanding tunnly
1. account api, channel details, global filters, ... are stored in config.json
2. load.py loads the details from config.json, account details are loaded into class conf defined in entities.py
channel details are loaded into dictionary, keys are source IDs, values are class channel defined in entities.py
3. each channel in config.json can take parameters
: show_name -> bool - If message should contain channel name at the top
: source_id -> int - Id of the source channel (where to take the messages from)
: channel_id -> int - Id to which messages are forwarded
: filt -> [str] - removes all of the words/characters/sentences from the message
: repl -> [[str, str], ...] - replaces everything in the message ["Replace this with", "with this"], paramter takes list of lists of 2 values
: black -> [str] - wont forward the message if it contains anything from this list
: filter_links -> [str] - removes all the link specified, dont put in whole link, do like this ["discord", "google"], only use this part of the link, the bot will take care of the rest
: globals -> bool - if global filter, replace, blacklist should be applied to this channel
: strip_random -> bool - if the bot should remove random non alphabet characters from the end of the message
: translate -> bool - if the message should be translated
: language -> str - to which language the message should be translated, taken to consideration only when the above parameter is true
: formatting_mode -> int - there is just 1 formatting mode defined in the channel_entity class at the moment, so not of much use
: empty_limit -> int - how many images without caption should be allowed to be forwarded, if the limit is reached, no more images without caption will be forwarded until image with caption is forwaded
: history_limit -> int - the bot has automatic spam detection that can not be turned off at the moment, this sets the limit to how many messages bot is allowed to store for controlling spam, each new message will be compared to the messages kept in the history and if it is 100% match it wont be forwarded
: reply_limit -> int - bot has the ability to copy message replies, this limits how many messages it can keep track of in this channel
4. in config.json there are 3 "global" paremeters, they behave similarly to those defined above, except they apply to each channel that has globals set to true
: filter
: replace
: blacklist

- Starting tunnly
1. set your configuration
2. open run.py
3. specify the configuration name, it has to match the configuration defined in config.json, right now its "sample"
4. run run.py
