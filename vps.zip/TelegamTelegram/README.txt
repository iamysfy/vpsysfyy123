
- Available options
1. BotBot - bot recieves and sends messages
2. UserUser - user recieves and sends messages
3. UserBot - user recieves messages, bot sends them - unavailable
4. BotUser - bot recieves messages, user sends them - unavailable
